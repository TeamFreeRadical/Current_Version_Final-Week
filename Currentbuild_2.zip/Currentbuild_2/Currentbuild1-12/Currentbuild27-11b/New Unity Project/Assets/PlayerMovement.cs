﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour 
{


	public float playerHp = 3;
	public float moveSpeed;
	public GameObject target;
	public float bounceSpd;
	//public bool doesBounce = false;
	public Vector3 tempVec;
	public float tempX;
	public float tempY;
	public float tempZ;
	public GlobalGameLogic gameLogic;

	public Transform myTransform;
	public Transform target2;
	public int moveSpeed2 = 2; 				
	public int rotationSpeed = 2; 
	public int rotationSpeed2 = 400;


	// Use this for initialization
	void Start () 
	{
	
	}

	void OnTriggerEnter (Collider other)
	{
		if(other.tag == "Enemy")
		{
			//gameObject.SetActive(false);
			playerHp = playerHp - 1;

			//tempVec.Set (transform.position.x + (tempX), transform.position.y + (tempY),transform.position.z + (tempZ));
			//transform.position = tempVec;
			//gameLogic.GameOver ();
		}

		if(other.tag == "EnemyLaser")
		{
			//gameObject.SetActive(false);
			playerHp = playerHp - 1;
			
			//tempVec.Set (transform.position.x + (tempX), transform.position.y + (tempY),transform.position.z + (tempZ));
			//transform.position = tempVec;
			//gameLogic.GameOver ();
		}

		if(other.tag == "Wall")
		{
			gameObject.SetActive(false);
			playerHp -= 1;
			
			tempVec.Set (transform.position.x + (tempX), transform.position.y + (tempY),transform.position.z + (tempZ));
			transform.position = tempVec;
			gameLogic.GameOver ();
		}

	}

//	void OnTriggerStay (Collider other)
//	{
//		doesBounce = true;
//
//		if (doesBounce == true)
//		{
//			rigidbody.AddForce(Vector3.up * bounceSpd,ForceMode.Impulse);
//			doesBounce = false;
//		}
//
//		else if (doesBounce == false)
//		{
//			rigidbody.AddForce(Vector3.up * 0,ForceMode.Impulse);
//		}
//	}

	
	// Update is called once per frame
	void Update ()	
	{	
		float translation = Input.GetAxis ("Vertical_Movement") * moveSpeed;	
		float translation2 = Input.GetAxis ("Horizontal_Movement") * moveSpeed;
		translation *= Time.deltaTime;
		translation2 *= Time.deltaTime;
		transform.Translate (translation2, -translation, 0);


		float horizontal = Input.GetAxis("Player_1_Rotate_H") * Time.deltaTime * moveSpeed;
		float vertical = Input.GetAxis("Player_1_Rotate_V") * Time.deltaTime * moveSpeed;
		float angle = Mathf.Atan2(horizontal, vertical) * Mathf.Rad2Deg; 
		transform.rotation = Quaternion.Euler(new Vector3(0, 0, -angle));

	









		if (playerHp == 0)
		{
			tempVec.Set (transform.position.x + (tempX), transform.position.y + (tempY),transform.position.z + (tempZ));
			transform.position = tempVec;
			gameLogic.GameOver ();
			gameObject.SetActive(false);
			//Destroy (gameObject);
		}


		//tempX = 0;
		//tempY = 0;
		//tempZ = 0;

		//Vector3 temp = target.transform.position;
		//temp.z = 0;


		//Vector3 relativePos = temp - transform.position;
	//	relativePos.Normalize();
		//Quaternion rotation = Quaternion.FromToRotation (Vector3.up, relativePos);
		                                              
		//transform.rotation = rotation;


	/*	if(Input.GetKey(KeyCode.W))
		{
			tempY = - bounceSpd;
			transform.Translate(Vector3.up*Time.deltaTime, Space.World);
			transform.position = transform.position + Vector3.up*moveSpeed*Time.deltaTime;
		}
		if(Input.GetKey(KeyCode.A))
		{
			tempX = bounceSpd;
			transform.Translate(Vector3.left*Time.deltaTime, Space.World);
			transform.position = transform.position + Vector3.left*moveSpeed*Time.deltaTime;
		}
		if(Input.GetKey(KeyCode.S))
		{
			tempY = bounceSpd;
			transform.Translate(Vector3.down*Time.deltaTime, Space.World);
			transform.position = transform.position + Vector3.down*moveSpeed*Time.deltaTime;
		}
		if(Input.GetKey(KeyCode.D))
		{
			tempX = - bounceSpd;
			transform.Translate(Vector3.right*Time.deltaTime, Space.World);
			transform.position = transform.position + Vector3.right*moveSpeed*Time.deltaTime;
		}
	*/
	}
}
