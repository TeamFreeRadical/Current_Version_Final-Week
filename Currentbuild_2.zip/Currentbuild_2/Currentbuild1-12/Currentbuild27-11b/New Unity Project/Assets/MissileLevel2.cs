﻿using UnityEngine;
using System.Collections;

public class MissileLevel2 : MonoBehaviour {

	public float speedBull;
	public Vector3 vectorBull;
	public GameObject impact;

	public GameObject missileDirect;
	public GameObject missileDirect2;


	public Rigidbody secondMissile;
	
	// Use this for initialization
	void Start () 
	{
		vectorBull.x = 0;//transform.rotation.x;
		vectorBull.y = speedBull;
		vectorBull.z = 0;
		rigidbody.AddRelativeForce (vectorBull,ForceMode.Impulse);
	}
	
	void OnTriggerEnter(Collider other) 
	{
		
		if(other.tag == "Enemy")
		{
			Rigidbody impact1;
			impact1 = Instantiate(impact, gameObject.transform.position,gameObject.transform.rotation) as Rigidbody;



			Rigidbody bulletInstance;
			bulletInstance = Instantiate(secondMissile, gameObject.transform.position,missileDirect.transform.rotation) as Rigidbody;


			Rigidbody bulletInstance2;
			bulletInstance2 = Instantiate(secondMissile, gameObject.transform.position,missileDirect2.transform.rotation) as Rigidbody;



			Destroy (other.gameObject);
			Destroy (gameObject);
		}
		
		if(other.tag == "Wall")
		{
			Rigidbody impact1;
			//impact1 = Instantiate(impact, gameObject.transform.position,gameObject.transform.rotation) as Rigidbody;
			Destroy (gameObject);
		}

		if(other.tag == "EnemyLaser")
		{
			Rigidbody impact1;
			//impact1 = Instantiate(impact, gameObject.transform.position,gameObject.transform.rotation) as Rigidbody;
			Destroy (gameObject);
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
