﻿using UnityEngine;
using System.Collections;

public class crossHair : MonoBehaviour {

	private Vector3 mousePosition;
	//private Vector3 whatevershit;
	public float moveSpeed = 0.1f;

	void Start ()
	{

	}
	// Update is called once per frame
	void Update () 
	{
		//mousePosition = Input.mousePosition;
		//mousePosition.z = 15;
		//Vector3 mp = Camera.main.ScreenToWorldPoint (mousePosition);
		//transform.position = mp;

	}
}
