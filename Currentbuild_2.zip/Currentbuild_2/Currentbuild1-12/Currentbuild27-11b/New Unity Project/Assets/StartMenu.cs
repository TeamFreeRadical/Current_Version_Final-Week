﻿using UnityEngine;
using System.Collections;

public class StartMenu : MonoBehaviour {





	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnMouseDown(){

		if (gameObject.name == "StartGame") {			
			Application.LoadLevel ("box crap");

				}
		if (gameObject.name == "HowToPlay") {
			Application.LoadLevel ("Instructions");

				}
		if (gameObject.name == "ExitGame") {
			Application.Quit();                        

			}
		}
}
