﻿using UnityEngine;
using System.Collections;

public class LordTele2 : MonoBehaviour {
	
	public GameObject activeTurret;
	public GlobalGameLogic gameLogicThing;
	
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
		if(gameLogicThing.teleCount2 == 1)
		{
			
			activeTurret.SetActive(true);
			
		}
		
	}
}