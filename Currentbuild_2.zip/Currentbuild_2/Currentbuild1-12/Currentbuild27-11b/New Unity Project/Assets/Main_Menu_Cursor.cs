﻿using UnityEngine;
using System.Collections;

public class Main_Menu_Cursor : MonoBehaviour {

	public int moveSpeed = 2;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		float translation20 = Input.GetAxis ("Cursor_V") * moveSpeed;	
		float translation22 = Input.GetAxis ("Cursor_H") * moveSpeed;
		translation20 *= Time.deltaTime;
		translation22 *= Time.deltaTime;
		transform.Translate (translation20, translation22, 0);

			
	}

	public void OnTriggerEnter (Collider col){

		if(col.gameObject.name == "StartGame") {
			Application.LoadLevel("box crap");
		}

		if(col.gameObject.name == "HowToPlay"){			
		   Application.LoadLevel ("Instructions");
		}

	}

}