﻿using UnityEngine;
using System.Collections;

public class BackToMenu : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetButton("Cursor_Back")) {
			Application.LoadLevel ("Start_Menu");		
		}
	}

}
