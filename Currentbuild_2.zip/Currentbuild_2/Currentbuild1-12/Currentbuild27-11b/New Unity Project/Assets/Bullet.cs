﻿using UnityEngine;
using System.Collections;

public class Bullet : MonoBehaviour {
	public float speedBull;
	public Vector3 vectorBull;
	public GameObject impact;

	// Use this for initialization
	void Start () 
	{
		vectorBull.x = 0;//transform.rotation.x;
		vectorBull.y = speedBull;
		vectorBull.z = 0;
		rigidbody.AddRelativeForce (vectorBull,ForceMode.Impulse);
	}

	void OnTriggerEnter(Collider other) 
	{

		if(other.tag == "Enemy")
		{
			Rigidbody impact1;
			impact1 = Instantiate(impact, gameObject.transform.position,gameObject.transform.rotation) as Rigidbody;
		Destroy (gameObject);
		}

		if(other.tag == "Wall")
		{
			Rigidbody impact1;
			impact1 = Instantiate(impact, gameObject.transform.position,gameObject.transform.rotation) as Rigidbody;
			Destroy (gameObject);
		}

	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
