﻿using UnityEngine;
using System.Collections;

public class ShootBullet : MonoBehaviour
{	

	public GUIText bombText;
	//public int bombCount = 3;


	public Rigidbody bulletPrefab;


	public Rigidbody bulletPrefab2;


	public Rigidbody bulletPrefab3;


	public Rigidbody bulletPrefab4;


	public Rigidbody missilePrefabUp;

	public Rigidbody missilePrefabThird;

	public float fireRate = 1.0f;
	public AudioClip shootLaser; 
	public AudioClip explodeBall;
	public bool gatling = false;
	public bool missile = false;

	public int gatlingUp = 0;
	public int missileUp = 0;

	public GameObject gunBarrel;
	public GameObject gunBarrel2;
	public GameObject gunBarrel3;
	public GameObject gatlingBarrel2;
	public GameObject gatlingBarrel3;
	//public float bulletSpeed = 0;

	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{


		//bombText.text = "BOMB X: " + bombCount;

		if(Input.GetKey("1"))
		{
			gatling = true;
			missile = false;
		}

		if(Input.GetKey ("2"))
		{
			gatling = false;
			missile = true;
		}

		if(Input.GetKey ("3"))
		{
			gatling = false;
			missile = false;
		}

		//if(Input.GetMouseButton(0)&& Time.time > fireRate && missile == true)
		if(Input.GetButton("Player_1_Shoot")&& Time.time > fireRate && missile == true)

		{


			if (missileUp == 2)
			{
				Rigidbody bulletInstance5;
				bulletInstance5 = Instantiate(missilePrefabUp, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;
				
			}

			if (missileUp == 3)
			{
				Rigidbody bulletInstance5;
				bulletInstance5 = Instantiate(missilePrefabThird, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;
				
			}


			if (missileUp < 2)
			{
				Rigidbody bulletInstance3;
				bulletInstance3 = Instantiate(bulletPrefab3, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;

			}	
			

			fireRate = Time.time + 0.7f;
		}

		//if(Input.GetMouseButton(0)&& Time.time > fireRate && gatling == true)
		if(Input.GetButton("Player_1_Shoot")&& Time.time > fireRate && gatling == true)
		{
			audio.PlayOneShot(shootLaser);
			Rigidbody bulletInstance;
			bulletInstance = Instantiate(bulletPrefab4, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;

			audio.PlayOneShot(shootLaser);


			Rigidbody bulletInstance3;
			bulletInstance = Instantiate(bulletPrefab4, gunBarrel2.transform.position,gunBarrel2.transform.rotation) as Rigidbody;

			if (gatlingUp == 2)
			{
			Rigidbody bulletInstance5;
			bulletInstance5 = Instantiate(bulletPrefab4, gunBarrel3.transform.position,gunBarrel3.transform.rotation) as Rigidbody;

			}

			if (gatlingUp == 3)
			{
				Rigidbody bulletInstance5;
				bulletInstance5 = Instantiate(bulletPrefab4, gunBarrel3.transform.position,gunBarrel3.transform.rotation) as Rigidbody;
				
				Rigidbody bulletInstance4;
				bulletInstance4 = Instantiate(bulletPrefab4, gatlingBarrel3.transform.position,gatlingBarrel3.transform.rotation) as Rigidbody;

				Rigidbody bulletInstance6;
				bulletInstance6 = Instantiate(bulletPrefab4, gatlingBarrel2.transform.position,gatlingBarrel2.transform.rotation) as Rigidbody;
			}

			
			Rigidbody bulletInstance2;
			bulletInstance2 = Instantiate(bulletPrefab2, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;
			fireRate = Time.time + 0.1f;
		}

		//if(Input.GetMouseButton(0)&& Time.time > fireRate && gatling == false && missile == false)
		if(Input.GetButton("Player_1_Shoot")&& Time.time > fireRate && gatling == false && missile == false)
		{
			audio.PlayOneShot(shootLaser);
			Rigidbody bulletInstance;
			bulletInstance = Instantiate(bulletPrefab, gunBarrel3.transform.position,gunBarrel3.transform.rotation) as Rigidbody;

			Rigidbody bulletInstance2;
			bulletInstance2 = Instantiate(bulletPrefab2, gunBarrel3.transform.position,gunBarrel3.transform.rotation) as Rigidbody;
			fireRate = Time.time + 0.2f;
		}
	}

	void OnTriggerEnter (Collider other)
	{
		if(other.tag == "Gatling")
		{
			gatlingUp = gatlingUp + 1;
			gatling = true;
			missile = false;
			Destroy(other.gameObject);
		}
		if(other.tag == "Missile")
		{
			missileUp = missileUp + 1;
			gatling = false;
			missile = true;
			fireRate = Time.time - 1f;
			Destroy(other.gameObject);
		}
		
	}
}
