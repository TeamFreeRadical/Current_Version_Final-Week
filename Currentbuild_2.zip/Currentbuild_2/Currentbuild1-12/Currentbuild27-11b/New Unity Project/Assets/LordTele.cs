﻿using UnityEngine;
using System.Collections;

public class LordTele : MonoBehaviour {

	public GameObject activeTurret;
	public GlobalGameLogic gameLogicThing;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

//		if(gameLogicThing.teleCount2 == 0)
//		{
//			
//			activeTurret.SetActive(true);
//			
//		}
	
	}

	void OnTriggerEnter (Collider other)
	{
		if(other.tag == "Player" && gameLogicThing.teleCount2 == 1)
		{
			activeTurret.SetActive (true);
			//shouldSpawn = true;
		}
		
	}
}
