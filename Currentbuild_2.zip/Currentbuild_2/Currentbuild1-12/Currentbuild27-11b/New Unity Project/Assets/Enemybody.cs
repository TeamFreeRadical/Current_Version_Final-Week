﻿using UnityEngine;
using System.Collections;

public class Enemybody : MonoBehaviour {

	public Vector3 mousePosition;
	//private Vector3 whatevershit;
	//public GameObject followThing;
	public Transform lookAtThing;
	public float moveSpeed = 0.1f;
	public Vector3 tempVec;
	public float tempX;
	public float tempY;
	public float tempZ;
	public float lockPos = 0; 
	
	void Start ()
	{

	}
	// Update is called once per frame
	void Update () 
	{

		transform.LookAt (lookAtThing);
	
		transform.rotation = Quaternion.Euler(transform.rotation.eulerAngles.x, transform.rotation.eulerAngles.y, transform.rotation.eulerAngles.z);
		//Vector3 mousePositon = new Vector3(followThing.transform.position.x,followThing.transform.position.y,followThing.transform.position.z);
		//transform.position = mousePositon;
		print(transform.position.x);

		//mousePosition.z = 15;
		//Vector3 mp = Camera.main.ScreenToWorldPoint (mousePosition);
		//transform.position = mp;
		
	}
}

